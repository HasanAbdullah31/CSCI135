/*
  Author: Hasan Abdullah
  Course: {135,136}
  Instructor: Gilbert Pajela
  Assignment: Lab 9 - drawPixel

  This function prints a character.
*/

#include <iostream>
using namespace std;

void drawPixel(char c) {
  cout << c;
  return;
}
